#ifndef _SEATD_WSCONS_H
#define _SEATD_WSCONS_H

int path_is_wscons(const char *path);

#endif
