package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.12.0"
	CoreName    = "CoreDNS"
	serverType  = "dns"
)
