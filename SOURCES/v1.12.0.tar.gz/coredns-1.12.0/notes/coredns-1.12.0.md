
This release adds some new features.  Of note:
* New multisocket plugin - allows CoreDNS to listen on multiple sockets
* New automaxprocs plugin - automatically sets GOMAXPROCS to the number of CPUs

## Brought to You By

Ben Kochie,
Chris O'Haver,
Emmanuel Ferdman,
Viktor


## Noteworthy Changes

* plugin/multisocket (https://github.com/coredns/coredns/pull/6882)
* plugin/automaxprocs (https://github.com/coredns/coredns/pull/6948)
